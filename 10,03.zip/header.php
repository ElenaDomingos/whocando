<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>WhoCanDo</title>
	<meta name="MobileOptimized" content="320"/>
	<meta name="HandheldFriendly" content="true"/>
	<meta name="description" content="">
	<meta name="keywords" content="">
	<link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
	<link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
	<script defer src="//use.fontawesome.com/releases/v5.0.1/js/all.js"></script>
	<link rel="stylesheet" href="main.css" />
	<script src="https://code.jquery.com/mobile/1.4.2/jquery.mobile-1.4.2.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
	<script src="js/jquery.validate.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<script src="js/jquery.validate.js"></script>
	<link rel="stylesheet" href="styles/fontaesome.css" />
	
	<link rel="stylesheet" type="text/css" href="css/demo.css" />
	<link rel="stylesheet" type="text/css" href="css/set1.css" />
	
	
	<script src='https://www.google.com/recaptcha/api.js'></script>
	
</head>
<body>

	<div class="topy">
		<a href="index.php"><div class="logo"></div></a>
		<div class="login"><a href="login.php">Login</a> <a href="register.php">Create account</a>
		</div>

	</div>